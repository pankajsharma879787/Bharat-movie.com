MOVIE HUB WEBSITE
Open index.html to preview.

TO ADD YOUR MOVIES:
Edit the movies array in script.js. Change name, category, year, genre, poster image URL, description and official/licensed watch link.

PUBLISHING:
This is a static website. Upload all files to a static web host. Then submit the public URL to Google Search Console for indexing.

Use only content you own or are licensed to publish.
