
const movies=[
{id:1,name:"Movie One",cat:"Bollywood",year:2026,genre:"Action",img:"https://via.placeholder.com/500x750?text=Movie+One",desc:"Add your own movie description here.",link:"#"},
{id:2,name:"Movie Two",cat:"Bollywood",year:2026,genre:"Drama",img:"https://via.placeholder.com/500x750?text=Movie+Two",desc:"Add your own movie description here.",link:"#"},
{id:3,name:"Movie Three",cat:"Hollywood",year:2026,genre:"Action",img:"https://via.placeholder.com/500x750?text=Movie+Three",desc:"Add your own movie description here.",link:"#"},
{id:4,name:"Movie Four",cat:"Hollywood",year:2026,genre:"Comedy",img:"https://via.placeholder.com/500x750?text=Movie+Four",desc:"Add your own movie description here.",link:"#"}];

function card(m){return `<article class="card"><img src="${m.img}" alt="${m.name}"><div class="info"><h3>${m.name}</h3><p class="muted">${m.cat} • ${m.year} • ${m.genre}</p><a class="watch" href="details.html?id=${m.id}">View Details</a></div></article>`}
function render(id,list){document.getElementById(id).innerHTML=list.length?list.map(card).join(""):"<p class='muted'>No movies found.</p>"}
function getMovie(){return movies.find(x=>x.id===Number(new URLSearchParams(location.search).get("id")))}
